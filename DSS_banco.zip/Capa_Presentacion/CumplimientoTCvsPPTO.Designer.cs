﻿namespace Capa_Presentacion
{
    partial class CumplimientoTCvsPPTO
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.lbLogro = new System.Windows.Forms.Label();
            this.lbEjecutado = new System.Windows.Forms.Label();
            this.lbMeta = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.combo_meses = new System.Windows.Forms.ComboBox();
            this.ver_reporte_btn = new System.Windows.Forms.Button();
            this.buscar_btn = new System.Windows.Forms.Button();
            this.ejecutado = new System.Windows.Forms.Label();
            this.meta = new System.Windows.Forms.Label();
            this.logro = new System.Windows.Forms.Label();
            this.txtmatricula = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.groupBox1.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbLogro
            // 
            this.lbLogro.AutoSize = true;
            this.lbLogro.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbLogro.ForeColor = System.Drawing.Color.Orange;
            this.lbLogro.Location = new System.Drawing.Point(220, 16);
            this.lbLogro.Name = "lbLogro";
            this.lbLogro.Size = new System.Drawing.Size(52, 24);
            this.lbLogro.TabIndex = 6;
            this.lbLogro.Text = "-------";
            // 
            // lbEjecutado
            // 
            this.lbEjecutado.AutoSize = true;
            this.lbEjecutado.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbEjecutado.Location = new System.Drawing.Point(223, 49);
            this.lbEjecutado.Name = "lbEjecutado";
            this.lbEjecutado.Size = new System.Drawing.Size(52, 24);
            this.lbEjecutado.TabIndex = 5;
            this.lbEjecutado.Text = "-------";
            // 
            // lbMeta
            // 
            this.lbMeta.AutoSize = true;
            this.lbMeta.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbMeta.Location = new System.Drawing.Point(223, 12);
            this.lbMeta.Name = "lbMeta";
            this.lbMeta.Size = new System.Drawing.Size(52, 24);
            this.lbMeta.TabIndex = 4;
            this.lbMeta.Text = "-------";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(177)))), ((int)(((byte)(106)))));
            this.label7.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(15, 9);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(467, 24);
            this.label7.TabIndex = 46;
            this.label7.Text = "ESTATUS CUMPLIMIENTO TARJETAS DE CREDITO";
            // 
            // combo_meses
            // 
            this.combo_meses.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.combo_meses.FormattingEnabled = true;
            this.combo_meses.Location = new System.Drawing.Point(169, 12);
            this.combo_meses.Name = "combo_meses";
            this.combo_meses.Size = new System.Drawing.Size(184, 33);
            this.combo_meses.TabIndex = 42;
            // 
            // ver_reporte_btn
            // 
            this.ver_reporte_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(100)))), ((int)(((byte)(182)))));
            this.ver_reporte_btn.FlatAppearance.BorderSize = 0;
            this.ver_reporte_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ver_reporte_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ver_reporte_btn.ForeColor = System.Drawing.Color.White;
            this.ver_reporte_btn.Location = new System.Drawing.Point(449, 328);
            this.ver_reporte_btn.Name = "ver_reporte_btn";
            this.ver_reporte_btn.Size = new System.Drawing.Size(184, 35);
            this.ver_reporte_btn.TabIndex = 48;
            this.ver_reporte_btn.Text = "Ver Reporte";
            this.ver_reporte_btn.UseVisualStyleBackColor = false;
            this.ver_reporte_btn.Click += new System.EventHandler(this.ver_reporte_btn_Click);
            // 
            // buscar_btn
            // 
            this.buscar_btn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buscar_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(51)))), ((int)(((byte)(72)))));
            this.buscar_btn.Cursor = System.Windows.Forms.Cursors.Default;
            this.buscar_btn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(100)))), ((int)(((byte)(182)))));
            this.buscar_btn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.buscar_btn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.buscar_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buscar_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.buscar_btn.ForeColor = System.Drawing.Color.Silver;
            this.buscar_btn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buscar_btn.Location = new System.Drawing.Point(449, 264);
            this.buscar_btn.Name = "buscar_btn";
            this.buscar_btn.Size = new System.Drawing.Size(184, 37);
            this.buscar_btn.TabIndex = 49;
            this.buscar_btn.Text = "Buscar";
            this.buscar_btn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.buscar_btn.UseVisualStyleBackColor = false;
            this.buscar_btn.Click += new System.EventHandler(this.buscar_btn_Click);
            // 
            // ejecutado
            // 
            this.ejecutado.AutoSize = true;
            this.ejecutado.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ejecutado.ForeColor = System.Drawing.Color.White;
            this.ejecutado.Location = new System.Drawing.Point(21, 49);
            this.ejecutado.Name = "ejecutado";
            this.ejecutado.Size = new System.Drawing.Size(124, 24);
            this.ejecutado.TabIndex = 3;
            this.ejecutado.Text = "EJECUTADO";
            // 
            // meta
            // 
            this.meta.AutoSize = true;
            this.meta.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.meta.ForeColor = System.Drawing.Color.White;
            this.meta.Location = new System.Drawing.Point(21, 12);
            this.meta.Name = "meta";
            this.meta.Size = new System.Drawing.Size(64, 24);
            this.meta.TabIndex = 2;
            this.meta.Text = "META";
            // 
            // logro
            // 
            this.logro.AutoSize = true;
            this.logro.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logro.ForeColor = System.Drawing.Color.White;
            this.logro.Location = new System.Drawing.Point(18, 16);
            this.logro.Name = "logro";
            this.logro.Size = new System.Drawing.Size(77, 24);
            this.logro.TabIndex = 1;
            this.logro.Text = "LOGRO";
            // 
            // txtmatricula
            // 
            this.txtmatricula.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtmatricula.Location = new System.Drawing.Point(449, 401);
            this.txtmatricula.Name = "txtmatricula";
            this.txtmatricula.Size = new System.Drawing.Size(181, 29);
            this.txtmatricula.TabIndex = 46;
            this.txtmatricula.Visible = false;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lbLogro);
            this.groupBox1.Controls.Add(this.logro);
            this.groupBox1.Location = new System.Drawing.Point(3, 76);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(382, 54);
            this.groupBox1.TabIndex = 50;
            this.groupBox1.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.lbEjecutado);
            this.panel1.Controls.Add(this.groupBox1);
            this.panel1.Controls.Add(this.lbMeta);
            this.panel1.Controls.Add(this.ejecutado);
            this.panel1.Controls.Add(this.meta);
            this.panel1.Location = new System.Drawing.Point(12, 77);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(388, 154);
            this.panel1.TabIndex = 50;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(177)))), ((int)(((byte)(106)))));
            this.label4.Font = new System.Drawing.Font("Century Gothic", 15.75F);
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(15, 33);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(50, 24);
            this.label4.TabIndex = 51;
            this.label4.Text = "MES";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Gold;
            this.label6.Font = new System.Drawing.Font("Century Gothic", 15.75F);
            this.label6.Location = new System.Drawing.Point(70, 33);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(0, 24);
            this.label6.TabIndex = 53;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Silver;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 15.75F);
            this.label5.Location = new System.Drawing.Point(78, 20);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(50, 24);
            this.label5.TabIndex = 54;
            this.label5.Text = "MES";
            // 
            // chart1
            // 
            chartArea1.AxisX.MajorGrid.Enabled = false;
            chartArea1.AxisX.TitleFont = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            chartArea1.AxisY.Enabled = System.Windows.Forms.DataVisualization.Charting.AxisEnabled.False;
            chartArea1.AxisY.MajorGrid.Enabled = false;
            chartArea1.Name = "ChartArea1";
            this.chart1.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            this.chart1.Legends.Add(legend1);
            this.chart1.Location = new System.Drawing.Point(62, 264);
            this.chart1.Name = "chart1";
            series1.ChartArea = "ChartArea1";
            series1.IsValueShownAsLabel = true;
            series1.Legend = "Legend1";
            series1.Name = "Ejecutado";
            series2.ChartArea = "ChartArea1";
            series2.IsValueShownAsLabel = true;
            series2.Legend = "Legend1";
            series2.Name = "Presupuesto";
            this.chart1.Series.Add(series1);
            this.chart1.Series.Add(series2);
            this.chart1.Size = new System.Drawing.Size(324, 166);
            this.chart1.TabIndex = 55;
            this.chart1.Text = "chart1";
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Checked = true;
            this.radioButton1.Location = new System.Drawing.Point(30, 23);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(14, 13);
            this.radioButton1.TabIndex = 56;
            this.radioButton1.TabStop = true;
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.radioButton3);
            this.panel2.Controls.Add(this.radioButton2);
            this.panel2.Controls.Add(this.radioButton1);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.combo_meses);
            this.panel2.Location = new System.Drawing.Point(406, 77);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(388, 154);
            this.panel2.TabIndex = 57;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Silver;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 15.75F);
            this.label2.Location = new System.Drawing.Point(78, 119);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(204, 24);
            this.label2.TabIndex = 60;
            this.label2.Text = "ENERO A LA FECHA";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Silver;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 15.75F);
            this.label1.Location = new System.Drawing.Point(78, 67);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(178, 24);
            this.label1.TabIndex = 59;
            this.label1.Text = "ULTIMOS 3 MESES";
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.Location = new System.Drawing.Point(30, 128);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(14, 13);
            this.radioButton3.TabIndex = 58;
            this.radioButton3.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(30, 76);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(14, 13);
            this.radioButton2.TabIndex = 57;
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // CumplimientoTCvsPPTO
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(57)))), ((int)(((byte)(80)))));
            this.ClientSize = new System.Drawing.Size(800, 608);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.chart1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.txtmatricula);
            this.Controls.Add(this.buscar_btn);
            this.Controls.Add(this.ver_reporte_btn);
            this.Controls.Add(this.label7);
            this.Name = "CumplimientoTCvsPPTO";
            this.Text = "CumplimientoTCvsPPTO";
            this.Load += new System.EventHandler(this.CumplimientoTCvsPPTO_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lbMeta;
        private System.Windows.Forms.Label lbEjecutado;
        private System.Windows.Forms.Label lbLogro;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox combo_meses;
        private System.Windows.Forms.Button ver_reporte_btn;
        private System.Windows.Forms.Button buscar_btn;
        private System.Windows.Forms.Label ejecutado;
        private System.Windows.Forms.Label meta;
        private System.Windows.Forms.Label logro;
        private System.Windows.Forms.TextBox txtmatricula;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart1;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.RadioButton radioButton2;
    }
}