﻿using System;
namespace Capa_Negocio
{
    public class ListadoCumplimientoTC
    {
        public int id_oficina { get; set; }
        public int ejec { get; set; }
        public int ppto { get; set; }
        public int diferencia { get; set; }
        public double porciento { get; set; }
        public string nombre_oficina { get; set; }



        //public DateTime fecha { get; set; }
    }
}